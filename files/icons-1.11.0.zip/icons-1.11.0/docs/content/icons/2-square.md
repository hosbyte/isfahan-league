---
title: 2 square
categories:
  - Shapes
tags:
  - number
  - numeral
---
